package com.example.login;

import org.springframework.data.domain.Page;

public interface StudentInterface {
	Page<LoginModel> findPaginated(int pageNo,int pageSize);
}
