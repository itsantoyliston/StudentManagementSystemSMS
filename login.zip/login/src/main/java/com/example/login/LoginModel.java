package com.example.login;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="basic")
public class LoginModel {

	@Id
	@Column(name="stu_roll")
	private String stuRoll;
	
	@Column
	private String stuName;
	
	@Column
	private String stuDOB;

	
	@Column
	private String stuEmail;
	
	@Column
	private String optradio;
	
	@Column
	private String department;
	

	public String getOptradio() {
		return optradio;
	}

	public void setOptradio(String optradio) {
		this.optradio = optradio;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getStuEmail() {
		return stuEmail;
	}

	public void setStuEmail(String stuEmail) {
		this.stuEmail = stuEmail;
	}

	public String getStuRoll() {
		return stuRoll;
	}

	public void setStuRoll(String stuRoll) {
		this.stuRoll = stuRoll;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuDOB() {
		return stuDOB;
	}

	public void setStuDOB(String stuDOB) {
		this.stuDOB = stuDOB;
	}
}
