package com.example.login;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="staff_login")
public class StaffModel {
	
	@Id
	@Column(name="staff_roll")
	private String staffRoll;
	
	public String getStaffRoll() {
		return staffRoll;
	}

	public void setStaffRoll(String staffRoll) {
		this.staffRoll = staffRoll;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getStaffDOB() {
		return staffDOB;
	}

	public void setStaffDOB(String staffDOB) {
		this.staffDOB = staffDOB;
	}

	public String getStaffEmail() {
		return staffEmail;
	}

	public void setStaffEmail(String staffEmail) {
		this.staffEmail = staffEmail;
	}

	@Column
	private String staffName;
	 
	@Column
	private String staffDOB;
	
	@Column
	private String staffEmail;
}
