package com.example.login;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="login")
public class RegisterModel {
	

	@Id
	@Column
	private String student_Id;
	
	@Column
	private String password;
	
	@Column
	private int role;
	
	@Column
	private String userEmail;

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStudent_Id() {
		return student_Id;
	}

	public void setStudent_Id(String student_Id) {
		this.student_Id = student_Id;
	}

	public String getPassword() {
		return this.password;
	}




	
}
