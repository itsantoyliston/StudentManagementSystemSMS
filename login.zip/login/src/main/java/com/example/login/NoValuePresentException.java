package com.example.login;

public class NoValuePresentException extends Exception{

	public NoValuePresentException(String error) {
		super(error);
	}
}
