package com.example.login;


import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.example.dateAPI.*;

@SpringBootApplication
@EnableScheduling 
public class LoginApplication {	


	
	
	public static void main(String[] args) {
		SpringApplication.run(LoginApplication.class, args);
//		   String databaseUrl = "jdbc:postgresql://192.168.0.4:5432/student";
//	        String username = "postgres";
//	        String password = "postgres";
//	        String backupFilePath = "/path/to/backup.sql";
//
//	        try {
//	            String command = String.format(
//	                "pg_dump -h 192.168.1.4 -U %s -F c -b -v -f %s %s",
//	                username, backupFilePath, databaseUrl
//	            );
//
//	            Process process = Runtime.getRuntime().exec(command);
//	            int exitCode = process.waitFor();
//
//	            if (exitCode == 0) {
//	                System.out.println("Database backup completed successfully.");
//	            } else {
//	                System.err.println("Database backup failed.");
//	            }
//	        } catch (IOException | InterruptedException e) {
//	            e.printStackTrace();
//	        }
	}
	
	
}


