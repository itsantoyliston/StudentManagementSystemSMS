package com.example.login;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestApplication {
	
	@Autowired
	private LoginRepository loginRep;
	
	@Autowired
	private RegisterRepository RegRep;
	
	@GetMapping("/findStudent")
	  public List<LoginModel> studentList() {
		  List<LoginModel> student=loginRep.findAll();
		  return student;
	  }
	  
	@PostMapping("/addStudent")
	  public String addStudent(@RequestBody LoginModel loginStu,Model model) {
		 boolean res=loginRep.findById(loginStu.getStuRoll()).isPresent();
		 if(res==true) {
			 return"Record already Exist";
		 }
		 else {
			 RegisterModel reg=new RegisterModel();
			 reg.setStudent_Id(loginStu.getStuRoll());
			 reg.setPassword("pass123");
			 reg.setRole(1);
			  loginRep.save(loginStu);
			  RegRep.save(reg);
			 
		 }
		 return "Insert Successfully";
	}
	 
	@GetMapping("/findLikeStudent")
	  public List<LoginModel> getStudent(@RequestBody String name) {
		List<LoginModel> student=loginRep.findBystuNameContainingIgnoreCase(name);
		return student;
	}
	
	@GetMapping("/Streamapi")
	  public Stream<LoginModel> getStudents1(@RequestBody String name) {
		List<LoginModel> student=loginRep.findAll();
		Stream<LoginModel> stuList=student.stream().filter(p -> p.getStuName().toLowerCase().contains(name.toLowerCase()));
		return stuList;
	}
	
	@GetMapping("/StreamGetAge")
	  public List<LoginModel> getStudentAge() {	    
		List<LoginModel> student=loginRep.findAll();
		List<LoginModel> stuList=student.stream().filter(p-> (LocalDate.now().getYear()-LocalDate.parse(p.getStuDOB()).getYear())>18).map(p->p).collect(Collectors.toList());
		return stuList;
	}
	
}
