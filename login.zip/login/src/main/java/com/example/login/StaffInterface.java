package com.example.login;

import org.springframework.data.domain.Page;

public interface StaffInterface {
	Page<StaffModel> findPaginated(int pageNo,int pageSize);
}
