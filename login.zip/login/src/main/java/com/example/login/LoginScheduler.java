package com.example.login;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.dateAPI.Localdate;

@Service
public class LoginScheduler {
	static int count=0;
	Logger log=LoggerFactory.getLogger(LoginScheduler.class);
	
	@Scheduled(cron = "${cronExpression}")
	public void cronJobSch()  {
		
		log.info("countvalue " +count++);
	}
	

}
