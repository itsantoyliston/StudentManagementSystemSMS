package com.example.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserInterImpl implements UserInterface{

	@Autowired
	public LoginRepository logRep;
	
	public Iterable<LoginModel> findAll() {
		return logRep.findAll();
	}
}
