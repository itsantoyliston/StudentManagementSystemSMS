package com.example.login;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sun.tools.sjavac.Log;

@Controller
public class studentController extends Exception{

	@Autowired
	public LoginRepository loginRep;

	@Autowired
	public RegisterRepository RegRep;

	@Autowired
	public StaffRepository staffRep;

	@Autowired
	public AdminRepository AdminRep;

	@Autowired
	public DepartRepository DepartRep;

	@Autowired
	private StudentInterface stuInter;

	@Autowired
	private StaffInterface staInter;

	@Autowired
	private UserInterface userRep;

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private LoginScheduler loginSchedul;

	@RequestMapping("back")
	public String back(HttpSession session, Model mod, HttpServletResponse response) throws IOException {
		String role = session.getAttribute("role").toString();
		switch (Integer.parseInt(role)) {
		case 1:
			LoginModel stuList = loginRep.findById(session.getAttribute("username").toString()).get();
			mod.addAttribute("students", stuList);
			mod.addAttribute("studentLogin", "student");
			mod.addAttribute("NoneConfig","blurConfig");

			return "detail.jsp";
		case 2:
			StaffModel staffList = staffRep.findById(session.getAttribute("username").toString()).get();
			List<LoginModel> stuLists = loginRep.findAll();
			mod.addAttribute("studentList", stuLists);
			mod.addAttribute("staff", staffList);
			mod.addAttribute("staffLogin", "staff");
			mod.addAttribute("NoneConfig","blurConfig");

			return "detail.jsp";
		case 3:
			AdminModel adminList = AdminRep.findById(session.getAttribute("username").toString()).get();
			List<LoginModel> stuLists1 = loginRep.findAll();
			List<StaffModel> staList = staffRep.findAll();
			mod.addAttribute("staffs", staList);
			mod.addAttribute("studentList", stuLists1);
			mod.addAttribute("admin", adminList);
			mod.addAttribute("adminLogin", "admin");
			return "detail.jsp";

		}
		return "detail.jsp";
	}

	@RequestMapping("/")
	public String home() {
		return "index.jsp";
	}

	@RequestMapping("staffForm")
	public String staffHome() {
		return "staff.jsp";
	}

	@RequestMapping("/login")
	public String login() {
		return "login.jsp";
	}

	@RequestMapping("stuDetail")
	public String studentDetails(Model mod) {
		try {
			mod.addAttribute("stuStaffsList", "stafflist");
			mod.addAttribute("staStudentsList", "stulist");
		} catch (Exception e) {
			e.getMessage();
		}
		return "/back";
	}

	@RequestMapping("staffDetail")
	public String staffDetails(Model mod, HttpSession session) {
		return findPaginated1(1, mod, session);
	}

	@RequestMapping("/checkDepartment")
	@ResponseBody
	public Object[] dependentDropdown(@RequestParam("degree") String degree) {
		List<DepartModel> department = DepartRep.findByDegree(degree);
		return department.toArray();

	}

	@RequestMapping("successLogin")
	public String successLog(RegisterModel regmod, HttpServletRequest request, Model mod) throws Exception  {
		try {
			boolean username = RegRep.findById(regmod.getStudent_Id()).isPresent();
			if (username == true) {
				RegisterModel loginList = RegRep.findById(regmod.getStudent_Id()).get();
				boolean pass = regmod.getPassword().equals(loginList.getPassword());
				if (pass == true) {
//					loginSchedul.cronJobSch();
					HttpSession session = request.getSession();
					session.setAttribute("username", loginList.getStudent_Id());
					session.setAttribute("role", loginList.getRole());
					return "redirect:/home";
				} else {
					mod.addAttribute("res", "Invalid Username and Password");
					return "login.jsp";
				}
			} else {
				mod.addAttribute("res", "Invalid Username and Password");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return "login.jsp";
	}

	@RequestMapping("home")
	public String homePage(HttpSession session, Model mod, HttpServletResponse response) throws IOException {
		if (session.getAttribute("username") == null) {
			response.sendRedirect("/login");
		} else {
			String role = session.getAttribute("role").toString();

			switch (Integer.parseInt(role)) {
			case 1:
				LoginModel stuList = loginRep.findById(session.getAttribute("username").toString()).get();
				mod.addAttribute("students", stuList);
				session.setAttribute("students", stuList);
				mod.addAttribute("studentLogin", "student");
				mod.addAttribute("NoneConfig","blurConfig");
				return "detail.jsp";
			case 2:
				StaffModel staffList = staffRep.findById(session.getAttribute("username").toString()).get();
				List<LoginModel> stuLists = loginRep.findAll();
				mod.addAttribute("staff", staffList);
				mod.addAttribute("studentList", stuLists);
				mod.addAttribute("staffLogin", "staff");
				mod.addAttribute("NoneConfig","blurConfig");

				return "detail.jsp";
			case 3:

				AdminModel adminList = AdminRep.findById(session.getAttribute("username").toString()).get();
				List<LoginModel> stuLists1 = loginRep.findAll();
				List<StaffModel> staList = staffRep.findAll();
				mod.addAttribute("staffs", staList);
				mod.addAttribute("studentList", stuLists1);
				mod.addAttribute("admin", adminList);
				mod.addAttribute("adminLogin", "admin");
				mod.addAttribute("stuStaffsList", "stafflist");
				mod.addAttribute("staStudentsList", "stulist");
				return "detail.jsp";
			}
		}
		return "login.jsp";
	}

	@PostMapping("/addcus")
	public String addUser(LoginModel loginStu, Model model, HttpServletResponse response, HttpSession session) {
		try {
			if (session.getAttribute("username") == null) {
				response.sendRedirect("/login");
			} else {
				boolean res = loginRep.findById(loginStu.getStuRoll()).isPresent();
				if (res == true) {
					model.addAttribute("res", "RollNo already Exist");
				} else {
					RegisterModel reg = new RegisterModel();
					reg.setStudent_Id(loginStu.getStuRoll());
					reg.setPassword("pass123");
					reg.setRole(1);
					reg.setUserEmail(loginStu.getStuEmail());
					loginRep.save(loginStu);
					RegRep.save(reg);
					return "/stuDetail";
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return "/";

	}

	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/login";

	}

	@RequestMapping("/checkRollExist")
	@ResponseBody
	public boolean RollExistOrNot(@RequestParam("stuRoll") String stuRoll, Model model) {
		boolean res = loginRep.findById(stuRoll).isPresent();
		if (res == true) {
			return true;
		} else {
			return false;
		}
	}

	@PostMapping("addstaff")
	public String addStaff(StaffModel loginStaff, Model model) {
		try {
			boolean res = staffRep.findById(loginStaff.getStaffRoll()).isPresent();
			
			if (res == true) {
				model.addAttribute("res", "RollNo already Exist");
			} else {
				RegisterModel reg = new RegisterModel();
				reg.setStudent_Id(loginStaff.getStaffRoll());
				reg.setPassword("pass123");
				reg.setRole(2);
				reg.setUserEmail(loginStaff.getStaffEmail());
				staffRep.save(loginStaff);
				RegRep.save(reg);
				return "/staffDetail";
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return "redirect:/staffForm";

	}

	@RequestMapping({"/edit/{id}" , "/edit"})
	public String showUpdateForm(@PathVariable(value = "id",required=false) String stuRoll, Model model){
		try {
			if(stuRoll==null) {
				throw new NoValuePresentException("Value Not Found");
			}
			else {
			LoginModel loginStu = loginRep.findById(stuRoll).get();
			model.addAttribute("stuDetail", loginStu);
			model.addAttribute("degree", loginStu.getOptradio());
			model.addAttribute("department", loginStu.getDepartment());
			return "/update";
			}
		} catch (NoValuePresentException e) {
			System.out.println(e.getMessage());
		}
		return "/back";
	}

	@RequestMapping("/editStu/{id}")

	public String showUpdateStu(@PathVariable(value = "id") String stuRoll, Model model) {
		try {
			LoginModel loginStu = loginRep.findById(stuRoll).get();
			model.addAttribute("stuDetail", loginStu);
		} catch (Exception e) {
			e.getMessage();
		}
		return "/updateStu";

	}

	@RequestMapping("/editSta/{id}")
	public String showUpdateSta(@PathVariable(value = "id") String staffRoll, Model model) {
		try {
			StaffModel loginStaff = staffRep.findById(staffRoll).get();
			model.addAttribute("staffDetail", loginStaff);
		} catch (Exception e) {
			e.getMessage();
		}
		return "/updateSta";
	}

	@RequestMapping("/editAdmin/{id}")
	public String showUpdateAdmin(@PathVariable(value = "id") String admin_id, Model model) {
		try {
			AdminModel loginAdmin = AdminRep.findById(admin_id).get();
			model.addAttribute("AdminDetail", loginAdmin);
		} catch (Exception e) {
			e.getMessage();
		}
		return "/updateAdm";
	}

	@RequestMapping("/editStaff/{id}")
	public String showUpdateStaff(@PathVariable(value = "id") String staffRoll, Model model) {
		try {
			StaffModel loginStaff = staffRep.findById(staffRoll).get();
			model.addAttribute("staffDetail", loginStaff);
		} catch (Exception e) {
			
		}
		return "/updateStaff";
	}

	@RequestMapping("/delete/{id}")
	public String deleteUser(@PathVariable(value = "id") String stuRoll, Model model) {
		try {
			
			LoginModel loginStu = loginRep.findById(stuRoll).orElse(null);
			RegisterModel regmod = RegRep.findById(stuRoll).orElse(null);
			if(loginStu==null || regmod==null ) {
				throw new NoValuePresentException("Value Not Found");
			}
			else {
			loginRep.delete(loginStu);
			RegRep.delete(regmod);
			}
			
		}
		catch(NoValuePresentException e) {
			System.out.println(e.getMessage());
		}
		return "/delete";
	}

	
	@RequestMapping("/deleteStaff/{id}")
	public String deleteStaff(@PathVariable(value = "id") String staffRoll, Model model) {
		try {
			StaffModel loginSta = staffRep.findById(staffRoll).orElse(null);
			RegisterModel regmod = RegRep.findById(staffRoll).orElse(null);
			staffRep.delete(loginSta);
			RegRep.delete(regmod);
		} catch (Exception e) {
			e.getMessage();
		}
		return "/staffDetail";
	}

	@RequestMapping("/update")
	public String update() {
		return "update.jsp";
	}

	@RequestMapping("/updateStu")
	public String updateStu() {
		return "updateStu.jsp";
	}

	@RequestMapping("/updateSta")
	public String updateSta() {
		return "curUpdateSta.jsp";
	}

	@RequestMapping("/updateAdm")
	public String updateAdm() {
		return "curUpdateAdm.jsp";
	}

	@RequestMapping("/updateStaff")
	public String updateStaff() {
		return "updateSta.jsp";
	}

	@RequestMapping("delete")
	public String delete() {
		return "/stuDetail";
	}

	
	@RequestMapping("updatefn")
	public String updateUser(LoginModel loginStu, Model model, HttpSession session) {
		try {
			String role = session.getAttribute("role").toString();
			switch (Integer.parseInt(role)) {
			case 2:
				loginRep.save(loginStu);
				List<LoginModel> stuList = loginRep.findAll();
				model.addAttribute("studentList", stuList);
				return "/stuDetail";

			case 3:
				loginRep.save(loginStu);
				return "/stuDetail";
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return "details.jsp";
	}

	@RequestMapping("updatefnStu")
	public String updateStu(LoginModel loginStu, Model model, HttpSession session) {

		loginRep.save(loginStu);

		LoginModel stuList = loginRep.findById(session.getAttribute("username").toString()).get();
		model.addAttribute("students", stuList);
		model.addAttribute("studentLogin", "student");
		return "detail.jsp";

	}

	@RequestMapping("updatefnSta")
	public String updatecurrentStaffs(StaffModel staffmod, Model model, HttpSession session) {

		staffRep.save(staffmod);
		StaffModel staffList = staffRep.findById(session.getAttribute("username").toString()).get();
		model.addAttribute("staff", staffList);
		model.addAttribute("staffLogin", "staff");
		return "detail.jsp";
	}

	@RequestMapping("updatefnStaff")
	public String updateSta(StaffModel loginStaff, Model model) {
		staffRep.save(loginStaff);
		return "/staffDetail";
	}

	@RequestMapping("updatefnAdm")
	public String updateAdmin(AdminModel loginAdmin, Model model) {
		AdminRep.save(loginAdmin);

		return "/back";
	}

	@RequestMapping("changePassword")
	@ResponseBody
	public boolean changePass(@RequestParam("newPassword") String oldPass, @RequestParam("passConfirm") String newPass,
			HttpSession session, HttpServletRequest request, HttpServletResponse response, Model model)
			throws IOException {
		try {
			if (session.getAttribute("username") == null) {
				response.sendRedirect("/login");
			} else {
				if (!(oldPass.equals(newPass))) {
					return false;
				} else {
					RegisterModel reg = RegRep.findById(session.getAttribute("username").toString()).get();
					reg.setPassword(oldPass);
					RegRep.save(reg);
				}
			}
		} catch (Exception e) {
			e.getMessage();
		}

		return true;
	}

	@RequestMapping("/page1/{pageNo}")
	public String findPaginated1(@PathVariable(value = "pageNo") int pageNo, Model model, HttpSession session) {
		try {
			int pageSize = 5;
			AdminModel adminList = AdminRep.findById(session.getAttribute("username").toString()).get();
			model.addAttribute("admin", adminList);
			List<LoginModel> stuLists1 = loginRep.findAll();
			List<StaffModel> staffList1 = staffRep.findAll();
			model.addAttribute("staffs", staffList1);
			model.addAttribute("studentList", stuLists1);
			Page<StaffModel> page = staInter.findPaginated(pageNo, pageSize);
			List<StaffModel> listpatient = page.getContent();
			model.addAttribute("currentPage", pageNo);
			model.addAttribute("totalPages", page.getTotalPages());
			model.addAttribute("totalItems", page.getTotalElements());
			model.addAttribute("staffs", listpatient);
			model.addAttribute("adminlogin", "admin");
			model.addAttribute("staffLogin", "staff");
			model.addAttribute("studentLogin", "student");
			model.addAttribute("staffsList", "stafflist");
			model.addAttribute("studentsList", "stulist");
			

		} catch (Exception e) {
			e.getMessage();

		}
		return "/main";
	}

	@RequestMapping("main")
	public String viewPage() {
		return "detail.jsp";
	}

	@GetMapping(value = "/api/users")
	public ResponseEntity<Iterable<LoginModel>> findAll() {
		try {
			return new ResponseEntity<Iterable<LoginModel>>(userRep.findAll(), HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<Iterable<LoginModel>>(HttpStatus.BAD_GATEWAY);
		}
	}

	@RequestMapping("forgot")
	public String forgotPage() {
		return "forgot.jsp";

	}

	@RequestMapping(value = "/forgotPass", method = RequestMethod.POST)
	public String processForgotPasswordForm(@RequestParam("checkRoll") String userRoll,
			@RequestParam("checkEmail") String userEmail, Model model, HttpServletRequest request,
			HttpSession session) {
		try {
			System.out.println(userRoll);
			boolean optional = RegRep.findById(userRoll).isPresent();

			if (!optional) {
				model.addAttribute("errorMessage", "RollNo does not exist");
				return "/forgot";
			} else {
				RegisterModel getUser = RegRep.findById(userRoll).get();
				String getEmail = getUser.getUserEmail();
				if (getEmail.equalsIgnoreCase(userEmail)) {
					session.setAttribute("forgotUser", userRoll);
					RegisterModel optional1 = RegRep.findById(userRoll).get();
					String appUrl = request.getScheme() + "://" + request.getServerName() + ":"
							+ request.getServerPort();
					SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
					passwordResetEmail.setFrom("gokultest67@gmail.com");
					passwordResetEmail.setTo(userEmail);
					passwordResetEmail.setSubject("Password Reset Request");
					passwordResetEmail.setText("To reset your password, click the link below:\n" + appUrl
							+ "/reset?token=" + optional1.getUserEmail());

					emailService.sendEmail(passwordResetEmail);
					model.addAttribute("successMessage", "A password reset link has been sent to " + userRoll);
				} else {
					model.addAttribute("emailMessage", "Email does not exist");
					return "/forgot";
				}

			}
		} catch (Exception e) {
			e.getMessage();
		}

		return "redirect:/forgot";

	}

	@GetMapping("reset")
	public String resetPage(@RequestParam(required = false, name = "token") String userEmail, HttpSession session) {

		session.setAttribute("userEmail", userEmail);
		return "reset.jsp";
	}

	@RequestMapping("/resetPass")
	public String setNewPassword(@RequestParam("newPass") String newPass, HttpSession session, Model model) {

		try {
			RegisterModel reg = RegRep.findById(session.getAttribute("forgotUser").toString()).get();
			String email = reg.getUserEmail();
			boolean emailRes = email.equalsIgnoreCase(session.getAttribute("userEmail").toString());
			if (emailRes) {
				System.out.println("hello");
				reg.setPassword(newPass);
				RegRep.save(reg);
				model.addAttribute("successMessage", "You have successfully reset your password.  You may now login.");
				return "redirect:/login";

			} else {

				model.addAttribute("invalidPassword", "block");
				return "/reset";
			}

		} catch (Exception e) {
			e.getMessage();

		}
		return "redirect:/reset";
	}

}
