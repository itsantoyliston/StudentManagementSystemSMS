package com.example.dateAPI;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class Localdate {
	static int count=0;
	Logger log=LoggerFactory.getLogger(Localdate.class);
//	public void local() {
//		System.out.println("-----------DateTimeFormatter------------");
//		LocalDateTime localDate = LocalDateTime.now();
//		DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern("MM/dd/YYYY");
//		System.out.println(dateformatter.format(localDate));
//
//		System.out.println("-----------ZoneDateTime------------");
//		LocalDateTime localDateTime = LocalDateTime.of(2023, 10, 5, 12, 0);
//		ZoneId sourceTimeZone = ZoneId.of("America/Los_Angeles");
//		ZonedDateTime sourceZonedDateTime = ZonedDateTime.of(localDateTime, sourceTimeZone);
//		System.out.println("Source Date and Time: " + sourceZonedDateTime);
//
//		ZoneId targetTimeZone = ZoneId.of("Asia/Kolkata");
//		ZonedDateTime targetZonedDateTime = sourceZonedDateTime.withZoneSameInstant(targetTimeZone);
//		System.out.println("Target Date and Time: " + targetZonedDateTime);
//	}
//	
//	@Scheduled(cron = "0 * 13 * * ?")
//	public void cronJobSch()  {
//		
//		log.info("countvalue " +count++);
//	}
//	
}
